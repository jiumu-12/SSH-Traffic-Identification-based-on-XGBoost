#!/bin/bash
func_dump(){
name=$1
echo $name
info=`tshark -r $name -T fields -e _ws.col.Info  -Y "frame.number==4 "`
len=`tshark -r $name -T fields -e frame.len  -Y "frame.number>=7 and frame.number<=36  " |  awk '{printf $1" "}' `
#total_packets=` capinfos $name | grep "Number of packets"| tr -d " " | cut -d ":" -f 2`



all_len[0]=`tshark -r $name -T fields -e frame.len |  awk '{printf "%s%s", sep, $0; sep=","} END{print ""}' `
all_time[0]=`tshark -r $name -T fields -e frame.time_delta|awk '{printf "%s%s", sep, $0; sep=","} END{print ""}'  `


all_len[1]=`tshark -r $name -T fields -e frame.len -Y 'tcp.dstport==22'|  awk '{printf "%s%s", sep, $0; sep=","} END{print ""}' `
all_time[1]=`tshark -r $name -T fields -e frame.time_delta_displayed -Y 'tcp.dstport==22'|  awk '{printf "%s%s", sep, $0; sep=","} END{print ""}' `


all_len[2]=`tshark -r $name -T fields -e frame.len -Y 'tcp.srcport==22'|  awk '{printf "%s%s", sep, $0; sep=","} END{print ""}' `
all_time[2]=`tshark -r $name -T fields -e frame.time_delta_displayed -Y 'tcp.srcport==22'|  awk '{printf "%s%s", sep, $0; sep=","} END{print ""}' `



#echo ${all_len[0]} >$1'.all_len_0.txt'
#echo ${all_time[0]} >$1'.all_time_0.txt'

#echo ${all_len[1]} >$1'.all_len_1.txt'
#echo ${all_time[1]} >$1'.all_time_1.txt'


#echo ${all_len[2]} >$1'.all_len_2.txt'
#echo ${all_time[2]} >$1'.all_time_2.txt'


#max_packet_length=`tshark -r $name -T fields -e frame.len  | awk '$0>x{x=$0};END{print x}'`
#min_packet_length=`tshark -r $name -T fields -e frame.len | awk 'NR==1{x=$0} NR>1 && $0<x{x=$0};END{print x}'`
#mean_packet_length=` tshark -r $name -T fields -e frame.len | awk '{ sum += $0; n++ } END { if (n > 0) print sum / n; }'`
#var_packet_length=`tshark -r $name -T fields -e frame.len | awk '{ sum += $0;v[n]=$0; n++; } END { mean=sum/n; for (i=0;i<n;i++){ var+=(v[i]-mean)*(v[i]-mean);  };printf("yb %f zt %f",var/n, var/(n-1))   }'`
#tshark -r $name -T fields -e frame.len | awk   '{ sum += $0;v[n]=$0; n++; } END { mean=sum/n; for (i=0;i<n;i++){ varzt+=(v[i]-mean)*(v[i]-mean)/n;varyb+=(v[i]-mean)*(v[i]-mean)/(n-1);  };printf("zt %f yb %f",varzt, varyb)   }'


total_len[0]=`python3 -c 'import statistics as S ;v=len(['${all_len[0]}'] );print(v)'`
max_len[0]=`python3 -c 'import statistics as S ;v=max(['${all_len[0]}'] );print(v)'`
min_len[0]=`python3 -c 'import statistics as S ;v=min(['${all_len[0]}'] );print(v)'`
mean_len[0]=`python3 -c 'import statistics as S ;v=S.mean(['${all_len[0]}'] );print(v)'`
var_len[0]=`python3 -c 'import statistics as S ;v=S.variance(['${all_len[0]}'] );print(v)'`
max_iat[0]=`python3 -c 'import statistics as S ;v=max(['${all_time[0]}'] );print(v)'`
min_iat[0]=`python3 -c 'import statistics as S ;v=min(['${all_time[0]}'] );print(v)'`
mean_iat[0]=`python3 -c 'import statistics as S ;v=S.mean(['${all_time[0]}'] );print(v)'`
var_iat[0]=`python3 -c 'import statistics as S ;v=S.variance(['${all_time[0]}'] );print(v)'`



#a to b   c to s
total_len[1]=`python3 -c 'import statistics as S ;v=len(['${all_len[1]}'] );print(v)'`
max_len[1]=`python3 -c 'import statistics as S ;v=max(['${all_len[1]}'] );print(v)'`
min_len[1]=`python3 -c 'import statistics as S ;v=min(['${all_len[1]}'] );print(v)'`
mean_len[1]=`python3 -c 'import statistics as S ;v=S.mean(['${all_len[1]}'] );print(v)'`
var_len[1]=`python3 -c 'import statistics as S ;v=S.variance(['${all_len[1]}'] );print(v)'`
max_iat[1]=`python3 -c 'import statistics as S ;v=max(['${all_time[1]}'] );print(v)'`
min_iat[1]=`python3 -c 'import statistics as S ;v=min(['${all_time[1]}'] );print(v)'`
mean_iat[1]=`python3 -c 'import statistics as S ;v=S.mean(['${all_time[1]}'] );print(v)'`
var_iat[1]=`python3 -c 'import statistics as S ;v=S.variance(['${all_time[1]}'] );print(v)'`

#b to a s to c

total_len[2]=`python3 -c 'import statistics as S ;v=len(['${all_len[2]}'] );print(v)'`
max_len[2]=`python3 -c 'import statistics as S ;v=max(['${all_len[2]}'] );print(v)'`
min_len[2]=`python3 -c 'import statistics as S ;v=min(['${all_len[2]}'] );print(v)'`
mean_len[2]=`python3 -c 'import statistics as S ;v=S.mean(['${all_len[2]}'] );print(v)'`
var_len[2]=`python3 -c 'import statistics as S ;v=S.variance(['${all_len[2]}'] );print(v)'`
max_iat[2]=`python3 -c 'import statistics as S ;v=max(['${all_time[2]}'] );print(v)'`
min_iat[2]=`python3 -c 'import statistics as S ;v=min(['${all_time[2]}'] );print(v)'`
mean_iat[2]=`python3 -c 'import statistics as S ;v=S.mean(['${all_time[2]}'] );print(v)'`
var_iat[2]=`python3 -c 'import statistics as S ;v=S.variance(['${all_time[2]}'] );print(v)'`


echo info: $info
echo len:  $len
echo total_len:$total_len
echo max_len: $max_len
echo min_len: $min_len
echo mean_len: $mean_len
echo var_len: $var_len
echo max_iat: $max_iat
echo min_iat:$min_iat
echo mean_iat:$mean_iat
echo var_iat:$var_iat

echo client to server

echo total_len:${total_len[1]}
echo max_len: ${max_len[1]}
echo min_len: ${min_len[1]}
echo mean_len: ${mean_len[1]}
echo var_len: ${var_len[1]}
echo max_iat: ${max_iat[1]}
echo min_iat:${min_iat[1]}
echo mean_iat:${mean_iat[1]}
echo var_iat:${var_iat[1]}

echo server to client

echo total_len:${total_len[2]}
echo max_len: ${max_len[2]}
echo min_len: ${min_len[2]}
echo mean_len: ${mean_len[2]}
echo var_len: ${var_len[2]}
echo max_iat: ${max_iat[2]}
echo min_iat:${min_iat[2]}
echo mean_iat:${mean_iat[2]}
echo var_iat:${var_iat[2]}

result=()
result+=($len)

result+=(${total_len})
result+=(${max_len})
result+=(${min_len})
result+=(${mean_len})
result+=(${var_len})
result+=(${max_iat})
result+=(${min_iat})
result+=(${mean_iat})
result+=(${var_iat})

result+=(${total_len[1]})
result+=(${max_len[1]})
result+=(${min_len[1]})
result+=(${mean_len[1]})
result+=(${var_len[1]})
result+=(${max_iat[1]})
result+=(${min_iat[1]})
result+=(${mean_iat[1]})
result+=(${var_iat[1]})

result+=(${total_len[2]})
result+=(${max_len[2]})
result+=(${min_len[2]})
result+=(${mean_len[2]})
result+=(${var_len[2]})
result+=(${max_iat[2]})
result+=(${min_iat[2]})
result+=(${mean_iat[2]})
result+=(${var_iat[2]})

#echo  ${result[@]}
#echo result ${result[@]%,}

split=''
str="$3,$info,"

for i in ${result[@] }
do
  
  str=$str$split$i
  split=','
  n+=1
done
echo "$str">>${2}
}




echo -n  >ftp_display.csv
for file in  ./ftp/*.pcap
do
func_dump $file ftp_display.csv $file
done

echo -n >http_display.csv

for file in ./http/*.pcap
do
func_dump $file http_display.csv $file
done



echo -n >scp_display.csv
for file in ./scp/*.pcap
do
func_dump $file scp_display.csv $file
done

 

