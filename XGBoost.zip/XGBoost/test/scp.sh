#!/bin/bash
#scp



for i in {1..10}
do
tcpdump -i any port 22 and host 192.168.87.160   -w output/scp/scp$i.pcap &
sleep 1
#ssh  -f -C -q -N   root@192.168.87.160 -D 1080 

list="5.zip  \
6.zip \
7.zip  \
8.zip  \
"
set -- $list
shift $(expr $RANDOM % $#)
file="$1"

echo  -----------------------------------------------------------------------------------query $url ----------
scp $file 192.168.87.160:/tmp


sleep 1 

pkill curl
ps -ef | grep ssh | grep "1080" | awk "{print \$2}" | xargs kill

pkill tcpdump

sleep 1
pkill -9 curl
ps -ef | grep ssh | grep "1080" | awk "{print \$2}" | xargs kill -9

pkill -9 tcpdump
sleep 1
done
