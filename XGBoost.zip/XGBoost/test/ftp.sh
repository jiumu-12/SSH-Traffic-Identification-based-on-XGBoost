#!/bin/bash
#ftp

#gost -L 8080

for i in {1..10}
do
tcpdump -i any port 22 and host 192.168.87.160   -w output/ftp/ftp$i.pcap &
sleep 1
ssh -f  -C -q -N   root@192.168.87.160 -D 1080 

list="ftp://xyl:xyl@192.168.87.160/5.zip  \
ftp://xyl:xyl@192.168.87.160/6.zip \
ftp://xyl:xyl@192.168.87.160/7.zip  \
ftp://xyl:xyl@192.168.87.160/8.zip  \
"
set -- $list
shift $(expr $RANDOM % $#)
url="$1"
echo  -----------------------------------------------------------------------------------query $url ----------
timeout 10s curl -x socks5h://127.0.0.1:1080  $url -o ftp_output


sleep 1
pkill curl

ps -ef | grep ssh | grep "1080" | awk "{print \$2}" | xargs kill

pkill tcpdump

sleep 1
pkill -9 curl
ps -ef | grep ssh | grep "1080" | awk "{print \$2}" | xargs kill -9
pkill -9 tcpdump
sleep 1
done